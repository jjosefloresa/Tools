--------------------------------------------------------------------------------------------------
-- ORACLE WEBCENTER FORMS RECOGNITION
-- NON-AP SAMPLE PROJECT - REPORTING
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
-- Oracle Reporting Table Creation Script
--------------------------------------------------------------------------------------------------
-- Description:
--
-- This script creates the Oracle database tables required for the Non-AP Sample Project eporting.
--
----------------------------------------------------------------------------------------------------

declare 

   v_cnt integer := 0;

begin

select count(*) into v_cnt from user_tables where TABLE_NAME = 'NONAPFIELDS';
if v_cnt = 1 then 
  execute immediate 'drop table NONAPFIELDS';
end if;

select count(*) into v_cnt from user_tables where TABLE_NAME = 'NONAPDOCSTATUS';
if v_cnt = 1 then 
  execute immediate 'drop table NONAPDOCSTATUS';
end if;

select count(*) into v_cnt from user_tables where TABLE_NAME = 'NONAPDOCUMENT';
if v_cnt = 1 then 
  execute immediate 'drop table NONAPDOCUMENT';
end if;

select count(*) into v_cnt from user_source where name = 'SP_NONAPDELETEREPORTINGRECORDS';
if v_cnt > 0 then 
  execute immediate 'drop procedure sp_NONAPdeleteReportingRecords';
end if;

end;
/

create table NONAPdocument (
   DOCUMENTNUMBER     varchar2(50)  default 'X00000000000' NOT NULL
 , VERSION            varchar2(10)                         NOT NULL
 , PROJECTNAME        varchar2(255)                        NOT NULL
 , BATCHNAME          varchar2(255) default '00000000'         NULL
 , PAGES              integer       default 0                  NULL
 , DPI_X              varchar2(5)   default '0'                NULL
 , DPI_Y              varchar2(5)   default '0'                NULL
 , OCRPAGES           integer       default 0                  NULL
 , CLASSNAMERTS       varchar2(255)                            NULL
 , CLASSNAMEV         varchar2(255)                            NULL
 , CLASS1NAME         varchar2(255)                            NULL
 , CLASS2NAME         varchar2(255)                            NULL
 , CLASS3NAME         varchar2(255)                            NULL
 , CLASS1RESULT       float                                    NULL
 , CLASS2RESULT       float                                    NULL
 , CLASS3RESULT       float                                    NULL
 , CLASS1ENGINE       varchar2(255)                            NULL
 , CLASS2ENGINE       varchar2(255)                            NULL
 , CLASS3ENGINE       varchar2(255)                            NULL
 , DATEIMPORTSTARTRTS date                                     NULL
 , DATEIMPORTENDRTS   date                                     NULL
 , DATEOCRSTARTRTS    date                                     NULL
 , DATEOCRENDRTS      date                                     NULL
 , DATECLASSRTS       date                                     NULL
 , DATECLASSENDRTS    date                                     NULL
 , DATEEXTRRTS        date                                     NULL
 , DATEEXTRENDRTS     date                                     NULL
 , DATECLASSV         date                                     NULL
 , DATESTARTV         date                                     NULL
 , DATEEXTRV          date                                     NULL
 , DATEEXPORTRTS      date                                     NULL
 , PIDOCRRTS          varchar2(6)                              NULL
 , PIDCLASSRTS        varchar2(6)                              NULL
 , PIDEXTRRTS         varchar2(6)                              NULL
 , PIDCLASSV          varchar2(6)                              NULL
 , PIDEXTRV           varchar2(6)                              NULL
 , PIDEXPORTRTS       varchar2(6)                              NULL
 , PCNAMEOCRRTS       varchar2(40)                             NULL
 , PCNAMECLASSRTS     varchar2(40)                             NULL
 , PCNAMEEXTRRTS      varchar2(40)                             NULL
 , PCNAMECLASSV       varchar2(40)                             NULL
 , PCNAMEEXTRV        varchar2(40)                             NULL
 , USERCLASSV         varchar2(20)                             NULL
 , USEREXTRV          varchar2(20)                             NULL
 , PCNAMEEXPORT       varchar2(40)                             NULL
 , FLAGEXPORTED       varchar2(1)                              NULL
 , CURRENT_STATUS     integer       default 0                  NULL
);

alter table NONAPdocument
  add constraint PK_NONAPdocument primary key (DOCUMENTNUMBER);

create index IX_NONAPDOC_Project on NONAPdocument ( 
   PROJECTNAME    ASC
 , DATEEXPORTRTS  ASC
 , CLASSNAMEV     ASC
 , USEREXTRV      ASC
 , CURRENT_STATUS ASC
);

create table NONAPFIELDS (
   DOCUMENTNUMBER     varchar2(50)  default 'X00000000000' NOT NULL
 , FIELDNAME          varchar2(50)                         NOT NULL
 , STATUS             varchar2(50)                         NOT NULL
 , DETAIL             varchar2(50)                         NOT NULL
 , OCRREJECTS         integer                                  NULL
 , CONTENTRTS         varchar2(255)                            NULL
 , CONTENTV           varchar2(255)                            NULL
 , NOOFCANDIDATES     integer                                  NULL
 , CONFIDENCE         float                                    NULL
 , DISTANCE           float                                    NULL
);


alter table NONAPFIELDS
  add constraint PK_NONAPFIELDS primary key (DOCUMENTNUMBER,FIELDNAME);

alter table NONAPFIELDS
  add constraint FK_NONAPFIELDS FOREIGN KEY
  (
  DOCUMENTNUMBER
  ) REFERENCES NONAPdocument
  (
  DOCUMENTNUMBER
  ) ON DELETE CASCADE;


create index IX_NONAPFIELDS_FldName on NONAPFIELDS (
   FIELDNAME  ASC
 , STATUS     ASC
 , CONTENTRTS ASC
 , CONTENTV   ASC
);

commit;


create table NONAPdocstatus (
   DOCUMENTNUMBER varchar2(50)  NOT NULL
 , STATUS         integer       NOT NULL
 , STATUSDATE     date          NOT NULL
);

alter table NONAPdocstatus 
  add constraint PK_NONAPdocstatus primary key (DOCUMENTNUMBER, STATUS, STATUSDATE);

alter table NONAPdocstatus
  add constraint FK_NONAPdocstatus FOREIGN KEY
  (
  DOCUMENTNUMBER
  ) REFERENCES NONAPdocument
  (
  DOCUMENTNUMBER
  ) ON DELETE CASCADE;


create or replace package pkg_NONAPdistiller
as
procedure sp_NONAPdeleteReportingRecords (p_Offset integer );                                                                                                   
end pkg_NONAPdistiller;
/

create or replace package body pkg_NONAPdistiller
as

procedure sp_NONAPdeleteReportingRecords (p_Offset integer ) is
begin
  delete from NONAPdocument
   where (trunc(SYSDATE)-trunc(DateExportRTS)) > p_Offset;
end;

end pkg_NONAPdistiller;
/

create or replace function IS_Date(p_CharVal Varchar2) Return Date
As

V_Cnt Date;

Begin

  Begin
    V_Cnt := To_Date(p_CharVal,'MM/DD/YYYY');
  Exception
    When Others Then
          V_Cnt := Null;
  End;
  
  Return v_Cnt;
  
Exception
  When Others Then Null;
End;
/

create or replace function IS_Number(p_CharVal Varchar2) Return Number
As

V_Cnt Number;

Begin

  Begin
    V_Cnt := To_Number(p_CharVal);
  Exception
    When Others Then
          V_Cnt := Null;
  End;
  
  Return v_Cnt;
  
Exception
  When Others Then Null;
End;
/

create or replace function ss
RETURN VARCHAR
AS
BEGIN
RETURN 'ss';
END;
/

create or replace function ms
RETURN VARCHAR
AS
BEGIN
RETURN 'ms';
END;
/

CREATE OR REPLACE FUNCTION DATEADD(vchDatePart VARCHAR, intOP in NUMBER, dt DATE)
RETURN DATE
AS
dt_tmp date;
BEGIN
	CASE UPPER(vchDatePart)
		WHEN 'DD' THEN -->>Day
			RETURN dt + intOP;
		WHEN 'YY' THEN -->>Year
			dt_tmp := ADD_MONTHS(dt,intOP*12);
		WHEN 'MM' THEN -->>Month
			dt_tmp := ADD_MONTHS(dt,intOP);
		WHEN 'HH' THEN -->>Hour
			dt_tmp := dt + (intOP / 24 );
		WHEN 'MI' THEN 	-->>Minute
			dt_tmp := dt + (intOP / 1440);  --1440=24*60
		WHEN 'SS' THEN -->>Second
			dt_tmp := dt + (intOP / 86400); --86400=24*60*60
		WHEN 'MS' THEN -->>Millisecond
			dt_tmp := dt + (floor(intOP / 1000) / 86400); --1000=MS --86400=24*60*60
		ELSE
			raise_application_error(-20100, '');
	END CASE;

  RETURN dt_tmp;
END;
/
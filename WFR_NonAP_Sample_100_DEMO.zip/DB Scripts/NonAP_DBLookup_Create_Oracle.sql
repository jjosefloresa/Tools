--------------------------------------------------------
--  DDL for Table DBLOOKUPSAMPLE
--------------------------------------------------------

  CREATE TABLE "DBLOOKUPSAMPLE" 
   (	"YOURREF" VARCHAR2(20 BYTE), 
	"DESCRIPTION" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into DBLOOKUPSAMPLE
SET DEFINE OFF;
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0003','Introduction to address extraction using an ASE');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0001','Image 1 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0001','Introduction to the Non-AP Sample Project');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0001','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR002','Image 2 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR002','Introduction to the concept of Classification');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR002','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0003','Image 3 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0003','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0004','Image 4 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0004','Introduction to extraction of an unknown format');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0004','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0005','Image 5 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0005','Introduction to extraction of a known format');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR0005','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR006','Image 6 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR006','Introduction to date extraction and formatting');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR006','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR007','Image 7 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR007','Introduction to table extraction');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR007','Belongs to DocClassA');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR009','Image 8 of 10');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR009','Another example of table extraction');
Insert into DBLOOKUPSAMPLE (YOURREF,DESCRIPTION) values ('WFR009','Belongs to DocClassA');

commit;
